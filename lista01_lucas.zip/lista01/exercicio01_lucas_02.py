valor = int(input('Valor em metros: '))
milimetros = valor*1000
print 'Valor em milimetros: %d' %milimetros
