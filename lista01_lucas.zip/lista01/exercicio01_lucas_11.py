tamanho = str(2**1000000)
print len(tamanho)
