a = int(input('Digite um numero: '))
b = int(input('Digite outro numero: '))
soma = (a+b)
print "A soma e: %d" %soma
