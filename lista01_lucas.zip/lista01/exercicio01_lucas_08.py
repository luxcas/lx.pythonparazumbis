f = float(input('Temperatura em Fahrenheit: '))
c = (f - 32) * 5 / 9
print '%.2f Celsius' %c
