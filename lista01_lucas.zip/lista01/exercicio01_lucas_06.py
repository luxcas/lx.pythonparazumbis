# encoding: utf-8
d = float(input('Distância em km: '))
v = float(input('Velocidade média em km/h: '))
tempo = d / v
print 'Tempo aproximado em horas: %.1f' %tempo
